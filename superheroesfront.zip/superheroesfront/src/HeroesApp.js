import React, { useState } from 'react';
import { MainPage } from './components/MainPage';
import { LoginComponent } from './components/LoginComponent';
const HeroesApp = () => {

    const [login, setLogin] = useState(false);


    return(
        <>
        { !login &&  <LoginComponent login={login} setLogin={setLogin}></LoginComponent>}
        { login && <MainPage></MainPage> }
        </>
    )
    
};


export default HeroesApp;
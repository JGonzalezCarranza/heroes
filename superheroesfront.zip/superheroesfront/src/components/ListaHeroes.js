import React from 'react'
import { Heroe } from './Heroe'
import { useFetchHeroes } from './hooks/useFetchHeroes';

export const ListaHeroes = ({ lista, offset, setNumeroHeroes }) => {
    const {data} = useFetchHeroes(lista, offset, setNumeroHeroes);
    
    return(
        <>
            {   
            
                data.map( elem => (
                    <Heroe {...elem}></Heroe>
                ))
            }
        </>
    )
}
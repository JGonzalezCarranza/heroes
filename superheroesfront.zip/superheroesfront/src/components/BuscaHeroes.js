import React, { useState } from 'react';
import PropTypes from 'prop-types';

export const BuscaHeroes = ( props ) => {

    const [ input, setInput ] = useState('');

    const handleInputChange = ( e ) => {
        setInput(e.target.value);
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        if(input.trim().length > 2){
            props.setBusqueda(input);
            props.setNumeroHeroes(0);
            props.setCounter(0);
        }
    }

    return (
        <div class="container">
            <div class="row">
                <div class="mb-3 p-3 mb-2 bg-info text-dark">
                    <label for="exampleInputEmail1" class="form-label">Nombre del heroe a buscar</label>
                <form onSubmit={ handleSubmit }>
                    <input class="form-control" type="text" value={ input }
                    onChange={ handleInputChange }>
                    </input>
                </form>
                </div>
            </div>
        </div>
    )
}

BuscaHeroes.propTypes = {
    setBusqueda: PropTypes.func.isRequired,
}

export const LoginComponent = (props) => {

    const [userName, setUserName] = ('');

    const handleChange = (event) => {
        
        setUserName({[event.target.name]:event.target.value});
    }

    const loginClicked = () => {
        if(userName !== ''){
            props.setLogin(true);
        }
    }

    return (

        <div class="container  bg-danger">
            <div class="row ">
                <div class="col col-lg-6 ">
                <h1 class="text-black">User Name:</h1> <input type="text" name="username" value={userName} onChange={handleChange}></input>
                </div> 
                
            </div>
            <br/>
            <div class="row">
                <div class="col col-lg-2">
            <button class="btn-primary" onClick={loginClicked}>Login</button>
                </div>
            </div>
        </div>
    )
    
}
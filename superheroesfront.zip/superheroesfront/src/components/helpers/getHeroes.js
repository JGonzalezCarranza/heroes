export const getHeroes = async( heroe, offset ) => {
    //encodeURI formatea el category, eliminando espacios etc
    const url = `http://localhost:9000/heroe/buscarPorNombre/${encodeURI(heroe)}/${encodeURI(offset)}`;
    const resp = await fetch( url );
    const respuesta = await resp.json();
    
    const listaHeroes=respuesta.map(elem => {
        return {
            id :elem.id,
            name: elem.name,
            description: elem.description,
            comics: elem.comics,
        }
    })
    console.log(listaHeroes);
    return listaHeroes;
}
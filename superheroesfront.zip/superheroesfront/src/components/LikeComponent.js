import React, { useState } from 'react'

export const LikeComponent = ({ id }) => {
    const [like, setLike] = useState(false);

    const sendLike = () => {
        const requestOptions = {
            method: 'POST',
            body: JSON.stringify({ title: 'Like' })
        };
        const url = `http://localhost:9000/like/${id}`;
        fetch(url, requestOptions)
            .then(response => response.json())
            .then(data => this.setState({ postId: data.id }));
        setLike(true);
    }

    return(
        <button class="btn btn-success" disabled={like} onClick={sendLike}>Like</button>
    )

}
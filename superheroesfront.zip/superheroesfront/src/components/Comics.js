import React, { useState } from 'react'


export const Comics = ({ available, items }) => {

    
    return(
        <>
            <p>{available}</p>
            {
                items.map( elem => (
                    <p>{elem.name}</p>
                ))
            }
        </>
    )
}
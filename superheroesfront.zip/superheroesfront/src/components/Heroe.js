import React, { useState } from 'react'
import {Comics} from './Comics'
import { LikeComponent } from './LikeComponent';
export const Heroe = ({ id, name, description, comics, numeroElementos }) => {

    const [check, setCheck] = useState(false);
    const [showComics, setShowComics] = useState(false);

    function hideDescription(){
        console.log("hide description");
        setCheck(check => !check);
    }

    function emptyDescription(){
        const withoutSpaces = description.trim();
        return withoutSpaces === "";
    }

    function emptyComics(){
        return comics.available === '0' ? true : false;
    }

    function hideComics(){
        console.log("hide description");
        setShowComics(showComics => !showComics);
    }


    return (
        <div>
            <hr></hr>
            <dt><h4 class="mt-5 p-3 mb-2 bg-danger text-white " >{name}</h4></dt>
            <div class="accordion" id="accordionExample">
                <div class="accordion-item">
                    <div class="accordion-header" id="headingOne">
                        { check !== true && !emptyDescription() && <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" onClick={hideDescription}> Ver descripcion</button>}
                        { check === true && <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" onClick={hideDescription}>Ocultar descripcion</button>}
                    </div>
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            {emptyDescription() && <p>Este heroe no dispone de descripcion</p>}
                            {check && <p>{description}</p>}
                        </div>
                    </div>
                </div> 
                <div class="accordion-item">
                    <div class="accordion-header" id="headingTwo">
                        { check !== true && !emptyComics() && <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo" onClick={hideComics}> Ver comics</button>}
                        { check === true && <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo" onClick={hideComics}>Ocultar comics</button>}
                    </div>
                    <div id="collapseTwo" class="accordion-collapse collapse show" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            {emptyComics() && <p>Este heroe no dispone de comics</p>}
                            {showComics && <Comics {...comics}></Comics>} 
                        </div>
                    </div>
                </div> 
            </div>

            <LikeComponent id={id} ></LikeComponent>
        </div>
    )
}
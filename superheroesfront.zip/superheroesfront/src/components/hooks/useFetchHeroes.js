import { useState, useEffect } from 'react'
import { getHeroes } from '../helpers/getHeroes';
export const useFetchHeroes = ( heroe, offset, setNumeroHeroes ) => {

    const [state, setState] = useState({
        data: [],
        loading: true,
    })

    useEffect( () => {
        getHeroes(heroe, offset).then(  elem => {
            setState({
                data:elem,
                loading:false,
            });
            setNumeroHeroes(elem.length);
        })
        
    }, [ heroe, offset, setNumeroHeroes ]);

    return state;
}
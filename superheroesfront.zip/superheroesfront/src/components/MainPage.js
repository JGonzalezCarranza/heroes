import React, { useState } from 'react';
import { BuscaHeroes } from './BuscaHeroes';
import { ListaHeroes } from './ListaHeroes';

export const MainPage = ({ value = 0 }) => {

    const [busquedas, setBusqueda] = useState('')

    const [ counter, setCounter ] = useState( value ); // []
    
    const [numeroHeroes, setNumeroHeroes] = useState(0);

    // handleAdd
    const handleAdd = () => {
        setCounter( counter + 10);
        // setCounter( (c) => c + 1 );
    }

    const handleSubtract = () => setCounter( counter - 10);
    

    return (
        <>
        <div class="container">
            <div class="row">
                <div class="col-md">
                    <h1 class="align-middle mt-5 p-3 mb-2 bg-danger text-white">Listado de heroes</h1>
                </div> 
                
            </div>
        </div>
        <BuscaHeroes setBusqueda={ setBusqueda } setNumeroHeroes={ setNumeroHeroes } setCounter={ setCounter }></BuscaHeroes>
        <ol>
            {
                
                    <ListaHeroes key={ busquedas } lista={ busquedas } offset={counter} setNumeroHeroes={setNumeroHeroes}/>
                
            }
        </ol>  
        <div class="container">
            <div class="row justify-content-md-center" >
                <div class="col col-lg-2">
                { numeroHeroes === 10 && <button type="button" class="btn btn-warning" onClick={handleAdd}>Siguiente</button> }
                </div>
                <div class="col col-lg-2">
                { counter !== 0 && <button type="button" class="btn btn-warning" onClick={handleSubtract}>Anterior</button>}
                </div>
            </div>
        </div>
        <br></br>
        <br></br>
        <br></br>
        </>
    )
};
